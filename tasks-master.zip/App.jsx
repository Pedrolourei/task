import {View, Text} from "react-native";
import styles from './AppStyles';

export default function App() {
 
  return (
    <View style={styles.container}>
      <Text>Rotas e Navegação</Text>
    </View>
  );
}
